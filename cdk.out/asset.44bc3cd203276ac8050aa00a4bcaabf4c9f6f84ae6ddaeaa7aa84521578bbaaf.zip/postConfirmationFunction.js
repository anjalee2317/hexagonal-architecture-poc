// Re-export the handler from the actual implementation
try {
  const { handler } = require('./src/adapters/in/postConfirmationFunction');
  exports.handler = handler;
} catch (error) {
  console.error('Error importing postConfirmationFunction:', error);
  
  // Fallback implementation if the module doesn't exist or has errors
  exports.handler = async (event, context) => {
    console.log('Post confirmation event:', JSON.stringify(event, null, 2));
    
    try {
      // Import required AWS SDK
      const AWS = require('aws-sdk');
      
      // Extract user attributes from the event
      const userId = event.userName;
      const userAttributes = event.request.userAttributes;
      
      // Set up DynamoDB client
      const dynamoDB = new AWS.DynamoDB.DocumentClient({
        region: process.env.REGION || 'us-east-1'
      });
      
      // Get the user table name from environment variables
      const userTableName = process.env.USER_TABLE_NAME;
      
      if (!userTableName) {
        console.error('USER_TABLE_NAME environment variable is not set');
        return event;
      }
      
      // Create user record in DynamoDB
      const userItem = {
        userId: userId,
        email: userAttributes.email,
        phoneNumber: userAttributes.phone_number,
        createdAt: new Date().toISOString(),
        preferences: {
          notifications: true,
          theme: 'light'
        }
      };
      
      await dynamoDB.put({
        TableName: userTableName,
        Item: userItem
      }).promise();
      
      console.log(`User profile created for ${userId} in table ${userTableName}`);
      
      // Send welcome email using SES
      const ses = new AWS.SES({ region: process.env.REGION || 'us-east-1' });
      
      // Verify the sender email address in SES before sending
      // For production, you should verify your domain and use a FROM_EMAIL environment variable
      const senderEmail = process.env.FROM_EMAIL || 'no-reply@yourdomain.com';
      
      // Create a personalized HTML email body
      const htmlBody = `
        <html>
          <head>
            <style>
              body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
              .container { max-width: 600px; margin: 0 auto; padding: 20px; }
              .header { background-color: #4CAF50; color: white; padding: 10px; text-align: center; }
              .content { padding: 20px; background-color: #f9f9f9; }
              .footer { font-size: 12px; text-align: center; margin-top: 20px; color: #777; }
              .button { display: inline-block; background-color: #4CAF50; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px; }
            </style>
          </head>
          <body>
            <div class="container">
              <div class="header">
                <h1>Welcome to Our Platform!</h1>
              </div>
              <div class="content">
                <h2>Hello ${userId},</h2>
                <p>Thank you for joining our platform. We're excited to have you on board!</p>
                <p>Your account has been successfully created and confirmed.</p>
                <p>Here's what you can do next:</p>
                <ul>
                  <li>Complete your profile</li>
                  <li>Explore our features</li>
                  <li>Create your first task</li>
                </ul>
                <p style="text-align: center; margin-top: 30px;">
                  <a href="https://yourdomain.com/dashboard" class="button">Go to Dashboard</a>
                </p>
              </div>
              <div class="footer">
                <p>If you have any questions, please contact our support team.</p>
                <p>&copy; ${new Date().getFullYear()} Your Company. All rights reserved.</p>
              </div>
            </div>
          </body>
        </html>
      `;
      
      // Create a plain text version for email clients that don't support HTML
      const textBody = `
        Welcome to Our Platform!
        
        Hello ${userId},
        
        Thank you for joining our platform. We're excited to have you on board!
        
        Your account has been successfully created and confirmed.
        
        Here's what you can do next:
        - Complete your profile
        - Explore our features
        - Create your first task
        
        Visit our dashboard at: https://yourdomain.com/dashboard
        
        If you have any questions, please contact our support team.
        
        &copy; ${new Date().getFullYear()} Your Company. All rights reserved.
      `;
      
      const emailParams = {
        Source: senderEmail,
        Destination: {
          ToAddresses: [userAttributes.email],
        },
        Message: {
          Subject: {
            Data: 'Welcome to Our Platform!',
            Charset: 'UTF-8'
          },
          Body: {
            Html: {
              Data: htmlBody,
              Charset: 'UTF-8'
            },
            Text: {
              Data: textBody,
              Charset: 'UTF-8'
            }
          }
        }
      };
      
      try {
        await ses.sendEmail(emailParams).promise();
        console.log(`Welcome email sent to ${userAttributes.email}`);
      } catch (emailError) {
        // Log the error but don't fail the function
        console.error('Error sending welcome email:', emailError);
        // If it's a SES verification error, log a helpful message
        if (emailError.code === 'MessageRejected') {
          console.log('SES email rejected. Make sure your sender email is verified in SES.');
        }
      }
    } catch (error) {
      console.error('Error in post confirmation handler:', error);
      // Important: We still return the event to allow the user to be confirmed
      // even if our additional processing fails
    }
    
    // Return the event to continue the flow
    return event;
  };
}
