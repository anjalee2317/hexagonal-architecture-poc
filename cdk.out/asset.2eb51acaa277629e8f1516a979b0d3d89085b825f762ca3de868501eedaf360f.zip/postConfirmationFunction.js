// Re-export the handler from the actual implementation
try {
  const { handler } = require('./src/adapters/in/postConfirmationFunction');
  exports.handler = handler;
} catch (error) {
  console.error('Error importing postConfirmationFunction:', error);
  
  // Fallback implementation if the module doesn't exist or has errors
  exports.handler = async (event, context) => {
    console.log('Post confirmation event:', JSON.stringify(event, null, 2));
    
    try {
      // Import required AWS SDK
      const AWS = require('aws-sdk');
      
      // Extract user attributes from the event
      const userId = event.userName;
      const userAttributes = event.request.userAttributes;
      
      // Set up DynamoDB client
      const dynamoDB = new AWS.DynamoDB.DocumentClient({
        region: process.env.REGION || 'us-east-1'
      });
      
      // Get the user table name from environment variables
      const userTableName = process.env.USER_TABLE_NAME;
      
      if (!userTableName) {
        console.error('USER_TABLE_NAME environment variable is not set');
        return event;
      }
      
      // Create user record in DynamoDB
      const userItem = {
        userId: userId,
        email: userAttributes.email,
        phoneNumber: userAttributes.phone_number,
        createdAt: new Date().toISOString(),
        preferences: {
          notifications: true,
          theme: 'light'
        }
      };
      
      await dynamoDB.put({
        TableName: userTableName,
        Item: userItem
      }).promise();
      
      console.log(`User profile created for ${userId} in table ${userTableName}`);
    } catch (error) {
      console.error('Error in post confirmation handler:', error);
      // Important: We still return the event to allow the user to be confirmed
      // even if our additional processing fails
    }
    
    // Return the event to continue the flow
    return event;
  };
}
