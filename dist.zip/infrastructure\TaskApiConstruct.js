"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.TaskApiConstruct = void 0;
const constructs_1 = require("constructs");
const cdk = __importStar(require("aws-cdk-lib"));
const dynamodb = __importStar(require("aws-cdk-lib/aws-dynamodb"));
const lambda = __importStar(require("aws-cdk-lib/aws-lambda"));
const apigateway = __importStar(require("aws-cdk-lib/aws-apigateway"));
const path = __importStar(require("path"));
/**
 * Custom CDK construct for Task API following Hexagonal Architecture principles
 */
class TaskApiConstruct extends constructs_1.Construct {
    constructor(scope, id, props = {}) {
        super(scope, id);
        const environmentName = props.environmentName || 'dev';
        // Create DynamoDB table for tasks
        this.taskTable = new dynamodb.Table(this, 'TaskTable', {
            partitionKey: {
                name: 'id',
                type: dynamodb.AttributeType.STRING
            },
            billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
            removalPolicy: cdk.RemovalPolicy.DESTROY // For demo purposes only
        });
        // Create Lambda function for task operations
        this.taskFunction = new lambda.Function(this, 'TaskFunction', {
            runtime: lambda.Runtime.NODEJS_18_X,
            handler: 'taskFunction.handler',
            code: lambda.Code.fromAsset(path.join(__dirname, '../dist.zip')),
            environment: {
                TASK_TABLE_NAME: this.taskTable.tableName,
                REGION: cdk.Stack.of(this).region,
                ENVIRONMENT: environmentName
            }
        });
        // Grant Lambda function permissions to access DynamoDB table
        this.taskTable.grantReadWriteData(this.taskFunction);
        // Add EventBus integration if provided
        if (props.eventBus) {
            this.taskFunction.addEnvironment('EVENT_BUS_NAME', props.eventBus.eventBusName);
            props.eventBus.grantPutEventsTo(this.taskFunction);
        }
        // Add Cognito integration if provided
        if (props.userPool) {
            this.taskFunction.addEnvironment('USER_POOL_ID', props.userPool.userPoolId);
        }
        // Create API Gateway REST API
        this.api = new apigateway.RestApi(this, 'TaskApi', {
            restApiName: 'Task API',
            description: 'API for task operations',
            defaultCorsPreflightOptions: {
                allowOrigins: apigateway.Cors.ALL_ORIGINS,
                allowMethods: apigateway.Cors.ALL_METHODS,
                allowHeaders: ['Content-Type', 'Authorization']
            }
        });
        // Create authorizer if Cognito User Pool is provided
        let authorizerProps = {};
        if (props.userPool) {
            const authorizer = new apigateway.CognitoUserPoolsAuthorizer(this, 'TaskApiAuthorizer', {
                cognitoUserPools: [props.userPool],
                authorizerName: 'TaskApiCognitoAuthorizer',
                identitySource: 'method.request.header.Authorization'
            });
            authorizerProps = {
                authorizer: authorizer,
                authorizationType: apigateway.AuthorizationType.COGNITO
            };
        }
        // Create API Gateway resources and methods
        const tasksResource = this.api.root.addResource('tasks');
        // GET /tasks - Get all tasks
        tasksResource.addMethod('GET', new apigateway.LambdaIntegration(this.taskFunction), authorizerProps);
        // POST /tasks - Create a task
        tasksResource.addMethod('POST', new apigateway.LambdaIntegration(this.taskFunction), authorizerProps);
        // Task-specific operations
        const taskResource = tasksResource.addResource('{taskId}');
        // GET /tasks/{taskId} - Get a task
        taskResource.addMethod('GET', new apigateway.LambdaIntegration(this.taskFunction), authorizerProps);
        // PUT /tasks/{taskId} - Update a task
        taskResource.addMethod('PUT', new apigateway.LambdaIntegration(this.taskFunction), authorizerProps);
        // DELETE /tasks/{taskId} - Delete a task
        taskResource.addMethod('DELETE', new apigateway.LambdaIntegration(this.taskFunction), authorizerProps);
        // PATCH /tasks/{taskId}/complete - Complete a task
        const completeResource = taskResource.addResource('complete');
        completeResource.addMethod('PATCH', new apigateway.LambdaIntegration(this.taskFunction), authorizerProps);
    }
}
exports.TaskApiConstruct = TaskApiConstruct;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiVGFza0FwaUNvbnN0cnVjdC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL2luZnJhc3RydWN0dXJlL1Rhc2tBcGlDb25zdHJ1Y3QudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsMkNBQXVDO0FBQ3ZDLGlEQUFtQztBQUNuQyxtRUFBcUQ7QUFDckQsK0RBQWlEO0FBQ2pELHVFQUF5RDtBQUV6RCwyQ0FBNkI7QUF3QjdCOztHQUVHO0FBQ0gsTUFBYSxnQkFBaUIsU0FBUSxzQkFBUztJQUs3QyxZQUFZLEtBQWdCLEVBQUUsRUFBVSxFQUFFLFFBQStCLEVBQUU7UUFDekUsS0FBSyxDQUFDLEtBQUssRUFBRSxFQUFFLENBQUMsQ0FBQztRQUVqQixNQUFNLGVBQWUsR0FBRyxLQUFLLENBQUMsZUFBZSxJQUFJLEtBQUssQ0FBQztRQUV2RCxrQ0FBa0M7UUFDbEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLFFBQVEsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLFdBQVcsRUFBRTtZQUNyRCxZQUFZLEVBQUU7Z0JBQ1osSUFBSSxFQUFFLElBQUk7Z0JBQ1YsSUFBSSxFQUFFLFFBQVEsQ0FBQyxhQUFhLENBQUMsTUFBTTthQUNwQztZQUNELFdBQVcsRUFBRSxRQUFRLENBQUMsV0FBVyxDQUFDLGVBQWU7WUFDakQsYUFBYSxFQUFFLEdBQUcsQ0FBQyxhQUFhLENBQUMsT0FBTyxDQUFDLHlCQUF5QjtTQUNuRSxDQUFDLENBQUM7UUFFSCw2Q0FBNkM7UUFDN0MsSUFBSSxDQUFDLFlBQVksR0FBRyxJQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxFQUFFLGNBQWMsRUFBRTtZQUM1RCxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQyxXQUFXO1lBQ25DLE9BQU8sRUFBRSxzQkFBc0I7WUFDL0IsSUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLGFBQWEsQ0FBQyxDQUFDO1lBQ2hFLFdBQVcsRUFBRTtnQkFDWCxlQUFlLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTO2dCQUN6QyxNQUFNLEVBQUUsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTTtnQkFDakMsV0FBVyxFQUFFLGVBQWU7YUFDN0I7U0FDRixDQUFDLENBQUM7UUFFSCw2REFBNkQ7UUFDN0QsSUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFFckQsdUNBQXVDO1FBQ3ZDLElBQUksS0FBSyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ25CLElBQUksQ0FBQyxZQUFZLENBQUMsY0FBYyxDQUFDLGdCQUFnQixFQUFFLEtBQUssQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLENBQUM7WUFDaEYsS0FBSyxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7UUFDckQsQ0FBQztRQUVELHNDQUFzQztRQUN0QyxJQUFJLEtBQUssQ0FBQyxRQUFRLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxjQUFjLEVBQUUsS0FBSyxDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUM5RSxDQUFDO1FBRUQsOEJBQThCO1FBQzlCLElBQUksQ0FBQyxHQUFHLEdBQUcsSUFBSSxVQUFVLENBQUMsT0FBTyxDQUFDLElBQUksRUFBRSxTQUFTLEVBQUU7WUFDakQsV0FBVyxFQUFFLFVBQVU7WUFDdkIsV0FBVyxFQUFFLHlCQUF5QjtZQUN0QywyQkFBMkIsRUFBRTtnQkFDM0IsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVztnQkFDekMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsV0FBVztnQkFDekMsWUFBWSxFQUFFLENBQUMsY0FBYyxFQUFFLGVBQWUsQ0FBQzthQUNoRDtTQUNGLENBQUMsQ0FBQztRQUVILHFEQUFxRDtRQUNyRCxJQUFJLGVBQWUsR0FBRyxFQUFFLENBQUM7UUFDekIsSUFBSSxLQUFLLENBQUMsUUFBUSxFQUFFLENBQUM7WUFDbkIsTUFBTSxVQUFVLEdBQUcsSUFBSSxVQUFVLENBQUMsMEJBQTBCLENBQUMsSUFBSSxFQUFFLG1CQUFtQixFQUFFO2dCQUN0RixnQkFBZ0IsRUFBRSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7Z0JBQ2xDLGNBQWMsRUFBRSwwQkFBMEI7Z0JBQzFDLGNBQWMsRUFBRSxxQ0FBcUM7YUFDdEQsQ0FBQyxDQUFDO1lBRUgsZUFBZSxHQUFHO2dCQUNoQixVQUFVLEVBQUUsVUFBVTtnQkFDdEIsaUJBQWlCLEVBQUUsVUFBVSxDQUFDLGlCQUFpQixDQUFDLE9BQU87YUFDeEQsQ0FBQztRQUNKLENBQUM7UUFFRCwyQ0FBMkM7UUFDM0MsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXpELDZCQUE2QjtRQUM3QixhQUFhLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFckcsOEJBQThCO1FBQzlCLGFBQWEsQ0FBQyxTQUFTLENBQUMsTUFBTSxFQUFFLElBQUksVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUV0RywyQkFBMkI7UUFDM0IsTUFBTSxZQUFZLEdBQUcsYUFBYSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQztRQUUzRCxtQ0FBbUM7UUFDbkMsWUFBWSxDQUFDLFNBQVMsQ0FBQyxLQUFLLEVBQUUsSUFBSSxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLGVBQWUsQ0FBQyxDQUFDO1FBRXBHLHNDQUFzQztRQUN0QyxZQUFZLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxJQUFJLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsZUFBZSxDQUFDLENBQUM7UUFFcEcseUNBQXlDO1FBQ3pDLFlBQVksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLElBQUksVUFBVSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUV2RyxtREFBbUQ7UUFDbkQsTUFBTSxnQkFBZ0IsR0FBRyxZQUFZLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBQzlELGdCQUFnQixDQUFDLFNBQVMsQ0FBQyxPQUFPLEVBQUUsSUFBSSxVQUFVLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxFQUFFLGVBQWUsQ0FBQyxDQUFDO0lBQzVHLENBQUM7Q0FDRjtBQWpHRCw0Q0FpR0MiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBDb25zdHJ1Y3QgfSBmcm9tICdjb25zdHJ1Y3RzJztcbmltcG9ydCAqIGFzIGNkayBmcm9tICdhd3MtY2RrLWxpYic7XG5pbXBvcnQgKiBhcyBkeW5hbW9kYiBmcm9tICdhd3MtY2RrLWxpYi9hd3MtZHluYW1vZGInO1xuaW1wb3J0ICogYXMgbGFtYmRhIGZyb20gJ2F3cy1jZGstbGliL2F3cy1sYW1iZGEnO1xuaW1wb3J0ICogYXMgYXBpZ2F0ZXdheSBmcm9tICdhd3MtY2RrLWxpYi9hd3MtYXBpZ2F0ZXdheSc7XG5pbXBvcnQgKiBhcyBpYW0gZnJvbSAnYXdzLWNkay1saWIvYXdzLWlhbSc7XG5pbXBvcnQgKiBhcyBwYXRoIGZyb20gJ3BhdGgnO1xuaW1wb3J0ICogYXMgZXZlbnRzIGZyb20gJ2F3cy1jZGstbGliL2F3cy1ldmVudHMnO1xuaW1wb3J0ICogYXMgY29nbml0byBmcm9tICdhd3MtY2RrLWxpYi9hd3MtY29nbml0byc7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgVGFza0FwaUNvbnN0cnVjdFxuICovXG5leHBvcnQgaW50ZXJmYWNlIFRhc2tBcGlDb25zdHJ1Y3RQcm9wcyB7XG4gIC8qKlxuICAgKiBPcHRpb25hbCBDb2duaXRvIFVzZXIgUG9vbCBmb3IgYXV0aG9yaXphdGlvblxuICAgKi9cbiAgdXNlclBvb2w/OiBjb2duaXRvLklVc2VyUG9vbDtcbiAgXG4gIC8qKlxuICAgKiBPcHRpb25hbCBFdmVudEJ1cyBmb3IgcHVibGlzaGluZyBldmVudHNcbiAgICovXG4gIGV2ZW50QnVzPzogZXZlbnRzLklFdmVudEJ1cztcbiAgXG4gIC8qKlxuICAgKiBFbnZpcm9ubWVudCBuYW1lIChlLmcuLCBkZXYsIHByb2QpXG4gICAqL1xuICBlbnZpcm9ubWVudE5hbWU/OiBzdHJpbmc7XG59XG5cbi8qKlxuICogQ3VzdG9tIENESyBjb25zdHJ1Y3QgZm9yIFRhc2sgQVBJIGZvbGxvd2luZyBIZXhhZ29uYWwgQXJjaGl0ZWN0dXJlIHByaW5jaXBsZXNcbiAqL1xuZXhwb3J0IGNsYXNzIFRhc2tBcGlDb25zdHJ1Y3QgZXh0ZW5kcyBDb25zdHJ1Y3Qge1xuICBwdWJsaWMgcmVhZG9ubHkgYXBpOiBhcGlnYXRld2F5LlJlc3RBcGk7XG4gIHB1YmxpYyByZWFkb25seSB0YXNrVGFibGU6IGR5bmFtb2RiLlRhYmxlO1xuICBwdWJsaWMgcmVhZG9ubHkgdGFza0Z1bmN0aW9uOiBsYW1iZGEuRnVuY3Rpb247XG5cbiAgY29uc3RydWN0b3Ioc2NvcGU6IENvbnN0cnVjdCwgaWQ6IHN0cmluZywgcHJvcHM6IFRhc2tBcGlDb25zdHJ1Y3RQcm9wcyA9IHt9KSB7XG4gICAgc3VwZXIoc2NvcGUsIGlkKTtcbiAgICBcbiAgICBjb25zdCBlbnZpcm9ubWVudE5hbWUgPSBwcm9wcy5lbnZpcm9ubWVudE5hbWUgfHwgJ2Rldic7XG5cbiAgICAvLyBDcmVhdGUgRHluYW1vREIgdGFibGUgZm9yIHRhc2tzXG4gICAgdGhpcy50YXNrVGFibGUgPSBuZXcgZHluYW1vZGIuVGFibGUodGhpcywgJ1Rhc2tUYWJsZScsIHtcbiAgICAgIHBhcnRpdGlvbktleToge1xuICAgICAgICBuYW1lOiAnaWQnLFxuICAgICAgICB0eXBlOiBkeW5hbW9kYi5BdHRyaWJ1dGVUeXBlLlNUUklOR1xuICAgICAgfSxcbiAgICAgIGJpbGxpbmdNb2RlOiBkeW5hbW9kYi5CaWxsaW5nTW9kZS5QQVlfUEVSX1JFUVVFU1QsXG4gICAgICByZW1vdmFsUG9saWN5OiBjZGsuUmVtb3ZhbFBvbGljeS5ERVNUUk9ZIC8vIEZvciBkZW1vIHB1cnBvc2VzIG9ubHlcbiAgICB9KTtcblxuICAgIC8vIENyZWF0ZSBMYW1iZGEgZnVuY3Rpb24gZm9yIHRhc2sgb3BlcmF0aW9uc1xuICAgIHRoaXMudGFza0Z1bmN0aW9uID0gbmV3IGxhbWJkYS5GdW5jdGlvbih0aGlzLCAnVGFza0Z1bmN0aW9uJywge1xuICAgICAgcnVudGltZTogbGFtYmRhLlJ1bnRpbWUuTk9ERUpTXzE4X1gsXG4gICAgICBoYW5kbGVyOiAndGFza0Z1bmN0aW9uLmhhbmRsZXInLFxuICAgICAgY29kZTogbGFtYmRhLkNvZGUuZnJvbUFzc2V0KHBhdGguam9pbihfX2Rpcm5hbWUsICcuLi9kaXN0LnppcCcpKSxcbiAgICAgIGVudmlyb25tZW50OiB7XG4gICAgICAgIFRBU0tfVEFCTEVfTkFNRTogdGhpcy50YXNrVGFibGUudGFibGVOYW1lLFxuICAgICAgICBSRUdJT046IGNkay5TdGFjay5vZih0aGlzKS5yZWdpb24sXG4gICAgICAgIEVOVklST05NRU5UOiBlbnZpcm9ubWVudE5hbWVcbiAgICAgIH1cbiAgICB9KTtcblxuICAgIC8vIEdyYW50IExhbWJkYSBmdW5jdGlvbiBwZXJtaXNzaW9ucyB0byBhY2Nlc3MgRHluYW1vREIgdGFibGVcbiAgICB0aGlzLnRhc2tUYWJsZS5ncmFudFJlYWRXcml0ZURhdGEodGhpcy50YXNrRnVuY3Rpb24pO1xuICAgIFxuICAgIC8vIEFkZCBFdmVudEJ1cyBpbnRlZ3JhdGlvbiBpZiBwcm92aWRlZFxuICAgIGlmIChwcm9wcy5ldmVudEJ1cykge1xuICAgICAgdGhpcy50YXNrRnVuY3Rpb24uYWRkRW52aXJvbm1lbnQoJ0VWRU5UX0JVU19OQU1FJywgcHJvcHMuZXZlbnRCdXMuZXZlbnRCdXNOYW1lKTtcbiAgICAgIHByb3BzLmV2ZW50QnVzLmdyYW50UHV0RXZlbnRzVG8odGhpcy50YXNrRnVuY3Rpb24pO1xuICAgIH1cbiAgICBcbiAgICAvLyBBZGQgQ29nbml0byBpbnRlZ3JhdGlvbiBpZiBwcm92aWRlZFxuICAgIGlmIChwcm9wcy51c2VyUG9vbCkge1xuICAgICAgdGhpcy50YXNrRnVuY3Rpb24uYWRkRW52aXJvbm1lbnQoJ1VTRVJfUE9PTF9JRCcsIHByb3BzLnVzZXJQb29sLnVzZXJQb29sSWQpO1xuICAgIH1cblxuICAgIC8vIENyZWF0ZSBBUEkgR2F0ZXdheSBSRVNUIEFQSVxuICAgIHRoaXMuYXBpID0gbmV3IGFwaWdhdGV3YXkuUmVzdEFwaSh0aGlzLCAnVGFza0FwaScsIHtcbiAgICAgIHJlc3RBcGlOYW1lOiAnVGFzayBBUEknLFxuICAgICAgZGVzY3JpcHRpb246ICdBUEkgZm9yIHRhc2sgb3BlcmF0aW9ucycsXG4gICAgICBkZWZhdWx0Q29yc1ByZWZsaWdodE9wdGlvbnM6IHtcbiAgICAgICAgYWxsb3dPcmlnaW5zOiBhcGlnYXRld2F5LkNvcnMuQUxMX09SSUdJTlMsXG4gICAgICAgIGFsbG93TWV0aG9kczogYXBpZ2F0ZXdheS5Db3JzLkFMTF9NRVRIT0RTLFxuICAgICAgICBhbGxvd0hlYWRlcnM6IFsnQ29udGVudC1UeXBlJywgJ0F1dGhvcml6YXRpb24nXVxuICAgICAgfVxuICAgIH0pO1xuICAgIFxuICAgIC8vIENyZWF0ZSBhdXRob3JpemVyIGlmIENvZ25pdG8gVXNlciBQb29sIGlzIHByb3ZpZGVkXG4gICAgbGV0IGF1dGhvcml6ZXJQcm9wcyA9IHt9O1xuICAgIGlmIChwcm9wcy51c2VyUG9vbCkge1xuICAgICAgY29uc3QgYXV0aG9yaXplciA9IG5ldyBhcGlnYXRld2F5LkNvZ25pdG9Vc2VyUG9vbHNBdXRob3JpemVyKHRoaXMsICdUYXNrQXBpQXV0aG9yaXplcicsIHtcbiAgICAgICAgY29nbml0b1VzZXJQb29sczogW3Byb3BzLnVzZXJQb29sXSxcbiAgICAgICAgYXV0aG9yaXplck5hbWU6ICdUYXNrQXBpQ29nbml0b0F1dGhvcml6ZXInLFxuICAgICAgICBpZGVudGl0eVNvdXJjZTogJ21ldGhvZC5yZXF1ZXN0LmhlYWRlci5BdXRob3JpemF0aW9uJ1xuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGF1dGhvcml6ZXJQcm9wcyA9IHtcbiAgICAgICAgYXV0aG9yaXplcjogYXV0aG9yaXplcixcbiAgICAgICAgYXV0aG9yaXphdGlvblR5cGU6IGFwaWdhdGV3YXkuQXV0aG9yaXphdGlvblR5cGUuQ09HTklUT1xuICAgICAgfTtcbiAgICB9XG5cbiAgICAvLyBDcmVhdGUgQVBJIEdhdGV3YXkgcmVzb3VyY2VzIGFuZCBtZXRob2RzXG4gICAgY29uc3QgdGFza3NSZXNvdXJjZSA9IHRoaXMuYXBpLnJvb3QuYWRkUmVzb3VyY2UoJ3Rhc2tzJyk7XG4gICAgXG4gICAgLy8gR0VUIC90YXNrcyAtIEdldCBhbGwgdGFza3NcbiAgICB0YXNrc1Jlc291cmNlLmFkZE1ldGhvZCgnR0VUJywgbmV3IGFwaWdhdGV3YXkuTGFtYmRhSW50ZWdyYXRpb24odGhpcy50YXNrRnVuY3Rpb24pLCBhdXRob3JpemVyUHJvcHMpO1xuICAgIFxuICAgIC8vIFBPU1QgL3Rhc2tzIC0gQ3JlYXRlIGEgdGFza1xuICAgIHRhc2tzUmVzb3VyY2UuYWRkTWV0aG9kKCdQT1NUJywgbmV3IGFwaWdhdGV3YXkuTGFtYmRhSW50ZWdyYXRpb24odGhpcy50YXNrRnVuY3Rpb24pLCBhdXRob3JpemVyUHJvcHMpO1xuICAgIFxuICAgIC8vIFRhc2stc3BlY2lmaWMgb3BlcmF0aW9uc1xuICAgIGNvbnN0IHRhc2tSZXNvdXJjZSA9IHRhc2tzUmVzb3VyY2UuYWRkUmVzb3VyY2UoJ3t0YXNrSWR9Jyk7XG4gICAgXG4gICAgLy8gR0VUIC90YXNrcy97dGFza0lkfSAtIEdldCBhIHRhc2tcbiAgICB0YXNrUmVzb3VyY2UuYWRkTWV0aG9kKCdHRVQnLCBuZXcgYXBpZ2F0ZXdheS5MYW1iZGFJbnRlZ3JhdGlvbih0aGlzLnRhc2tGdW5jdGlvbiksIGF1dGhvcml6ZXJQcm9wcyk7XG4gICAgXG4gICAgLy8gUFVUIC90YXNrcy97dGFza0lkfSAtIFVwZGF0ZSBhIHRhc2tcbiAgICB0YXNrUmVzb3VyY2UuYWRkTWV0aG9kKCdQVVQnLCBuZXcgYXBpZ2F0ZXdheS5MYW1iZGFJbnRlZ3JhdGlvbih0aGlzLnRhc2tGdW5jdGlvbiksIGF1dGhvcml6ZXJQcm9wcyk7XG4gICAgXG4gICAgLy8gREVMRVRFIC90YXNrcy97dGFza0lkfSAtIERlbGV0ZSBhIHRhc2tcbiAgICB0YXNrUmVzb3VyY2UuYWRkTWV0aG9kKCdERUxFVEUnLCBuZXcgYXBpZ2F0ZXdheS5MYW1iZGFJbnRlZ3JhdGlvbih0aGlzLnRhc2tGdW5jdGlvbiksIGF1dGhvcml6ZXJQcm9wcyk7XG4gICAgXG4gICAgLy8gUEFUQ0ggL3Rhc2tzL3t0YXNrSWR9L2NvbXBsZXRlIC0gQ29tcGxldGUgYSB0YXNrXG4gICAgY29uc3QgY29tcGxldGVSZXNvdXJjZSA9IHRhc2tSZXNvdXJjZS5hZGRSZXNvdXJjZSgnY29tcGxldGUnKTtcbiAgICBjb21wbGV0ZVJlc291cmNlLmFkZE1ldGhvZCgnUEFUQ0gnLCBuZXcgYXBpZ2F0ZXdheS5MYW1iZGFJbnRlZ3JhdGlvbih0aGlzLnRhc2tGdW5jdGlvbiksIGF1dGhvcml6ZXJQcm9wcyk7XG4gIH1cbn1cbiJdfQ==