// Main handler file for post-confirmation Lambda function
const { handler } = require('./src/adapters/in/postConfirmationFunction');

exports.handler = handler;
